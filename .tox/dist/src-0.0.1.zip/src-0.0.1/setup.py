from setuptools import setup, find_packages


setup(
    name="src",
    version="0.0.1",
    description="wineq_package",
    author=["abhishekr.ar53@gmail.com"],
    packages=find_packages(),
    licennse="MIT"
)